@echo Off
@echo 1��.
set JAVA_HOME="D:\QQGameswever\jdk"
set JAVAC=%JAVA_HOME%\bin\javac
set JAVA_BIN=%JAVA_HOME%\bin\java
set PATH=.;%JAVA_HOME%\bin
set CLASSPATH=.;%JAVA_HOME%\lib\dt.jar;%JAVA_HOME%\lib\tools.jar;%JAVA_HOME%\lib\rt.jar;%CD%\ojdbc14.jar
@java -server -jar qq1742312455.jar
@echo ����ʧ��
pause
